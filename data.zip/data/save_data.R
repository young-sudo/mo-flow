library(MOFA2)
library(MOFAdata)

utils::data("CLL_data")
write.csv(data.frame(CLL_data$Drugs), '/Users/janabraunger/Documents/Courses/2024_DeepLife/data/drugs.csv')
write.csv(data.frame(CLL_data$Methylation), '/Users/janabraunger/Documents/Courses/2024_DeepLife/data/methylation.csv')
write.csv(data.frame(CLL_data$mRNA), '/Users/janabraunger/Documents/Courses/2024_DeepLife/data/mRNA.csv')
write.csv(data.frame(CLL_data$Mutations), '/Users/janabraunger/Documents/Courses/2024_DeepLife/data/mutations.csv')
